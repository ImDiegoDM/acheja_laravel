<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FidelityCode extends Model
{
    //
}
