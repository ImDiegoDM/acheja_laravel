<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FidelitySolicitation extends Model
{
    //
}
