<?php $__env->startComponent('mail::message'); ?>
# Introduction

Olá <?php echo e($user->name); ?> seja bem vindo ao Ache Já, aqui nós faremos de tudo para que o seu negocio ganhe a visibilidade que você merece.

Equipe,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
