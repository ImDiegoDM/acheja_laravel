<p class="p-relative horizontal-center float-sm-right">
  <i class="fa fa-user-circle m-1" style="color: #00aede;" aria-hidden="true"></i>
  <?php echo e(auth()->user()->name); ?></p>
