<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-2 pt-2 px-0">
        <a href="<?php echo e(env('APP_URL').'/admin/home'); ?>"><img src="<?php echo e(URL::asset('public/img/acheja.png')); ?>" class="p-relative horizontal-center " style="width:100%;" alt=""></a>
      </div>
      <div class="col-sm-7 pt-2 ">
        <h4 class="p-relative horizontal-center float-sm-right text-center menu-name smooth-border" style="width:90%;">Usuarios</h4>
      </div>
      <div class="col-sm-3">
        <?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  <hr class="mt-2 mb-4">
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="myContainer absoluteFullcontent">
    <h4 class="mt-3">Usuarios cadastrados no sistema</h4>
    <div class="max100">
      <table class="table table-striped">
        <tr>
          <th>Nome</th>
          <th>Email</th>
          <th>Telefone</th>
          <th>Tipo</th>
          <th>Possui acesso?</th>
          <th>Criado em</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover" onclick="showCliente(<?php echo e($user->id); ?>)">
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td><?php echo e($user->phone); ?></td>
              <td><?php echo e($user->user_type->name); ?></td>
              <?php if($user->have_acess): ?>
                <td>sim</td>
              <?php else: ?>
                <td>não</td>
              <?php endif; ?>
              <td><?php echo e($user->created_at->setTimezone('-4')->format('d/m/Y')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
    </div>
  </div>

  <script type="text/javascript">
    function showCliente(index) {
      window.location.href="<?php echo e(env('APP_URL')); ?>/admin/user/"+index;
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>