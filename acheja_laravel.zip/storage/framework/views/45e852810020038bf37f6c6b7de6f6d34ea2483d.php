<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-2 pt-2 px-0">
        <a href="<?php echo e(env('APP_URL').'/public/home'); ?>"><img src="<?php echo e(URL::asset('img/acheja.png')); ?>" class="p-relative horizontal-center " style="width:100%;" alt=""></a>
      </div>
      <div class="col-sm-7 pt-2 ">
        <h3 class="p-relative horizontal-center float-sm-right text-center menu-name smooth-border" style="width:90%;">Gestão de conteudo</h3>
      </div>
      <div class="col-sm-3">
        <?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
  </div>
  <hr class="mt-2 mb-4">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
  <script type="text/javascript">
  $(document).ready(function() {
    $('#modalmessage').modal('show');
  });
  </script>
  <!-- Modal message -->
  <div class="modal fade" id="modalmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Sucesso</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form class="" action="<?php echo e(env('APP_URL').'/public/content/category'); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <div class="modal-body">
            <?php echo e(Session::get('success')); ?>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-confirm" data-dismiss="modal">Ok!</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php endif; ?>


<!-- Modal Category -->
<div class="modal fade" id="modalCategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Adicionar categoria</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form class="" action="<?php echo e(env('APP_URL').'/public/content/category'); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <div class="form-group">
            <label for="name">Nome</label>
            <input required type="text" class="form-control" id="name" name="name" value="">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
          <input type="submit" class="btn btn-confirm" value="Adicionar">
        </div>
      </form>
    </div>
  </div>
</div>


<?php echo $__env->make('layout.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="myContainer flexDislpayCenter-h row">
    <div class="col-sm-3">
      <div class="">
        <p data-toggle="modal" data-target="#modalCategory"><i style="color:#00aede" class="fa fa-plus-circle d-inline" style="margin:auto; width:.8em;" aria-hidden="true"></i> Adicionar Categoria</p>
        <?php if(request()->category): ?>
          <p class="hover"><i style="color:rgb(239, 115, 115)" class="fa fa-times-circle d-inline" style="margin:auto; width:.8em;" aria-hidden="true"></i> Remover Categoria</p>
        <?php endif; ?>
      </div>
      <div class="list-group" style="">
        <h4 class="list-group-item">Categorias</h4>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a onclick=<?php echo e("goToCategory(".$cat->id.")"); ?> class="<?php
          if(intval(request()->category)==$cat->id){
            //dd(intval(request()->category));
            echo "list-group-item active";
          }
          else {
            echo "list-group-item";
          }
          ?>" ><?php echo e($cat->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-3">
        <h4 class="list-group-item"><?php echo e($state->name); ?></h4>
        <?php $__currentLoopData = $state->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a onclick="<?php echo e("goToCity(".$city->id.")"); ?>" class="<?php
            if(intval(request()->city)==$city->id){
              //dd(intval(request()->category));
              echo "list-group-item active";
            }
            else {
              echo "list-group-item";
            }
           ?>"><?php echo e($city->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-3">
      <div class="list-group" style="">
        <h4 class="list-group-item">Região</h4>
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a onclick=<?php echo e("goToCategory(".$region->id.")"); ?> class="<?php
          if(intval(request()->$region)==$region->id){
            //dd(intval(request()->category));
            echo "list-group-item active";
          }
          else {
            echo "list-group-item";
          }
          ?>" ><?php echo e($region->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <script src="<?php echo e(URL::asset('js/Filter.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>