<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-2 pt-2 px-0">
        <a href="<?php echo e(env('APP_URL').'/public/home'); ?>"><img src="<?php echo e(URL::asset('img/acheja.png')); ?>" class="p-relative horizontal-center " style="width:100%;" alt=""></a>
      </div>
    </div>
  </div>
  <hr class="mt-2 mb-4">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="myContainer">
      <div class="form-group col-sm-12">Senha cadastrada com sucesso, para pode acessar a nossa plataforma digite o seu e-mail e sua senha na tela de login</div>
      <a class="btn btn-cofirm" href="<?php echo e(env('APP_URL').'/public/login'); ?>"></a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>