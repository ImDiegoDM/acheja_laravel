<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-8 py-3 px-0">
        <h1 class="text-center menu-name smooth-border" style="max-width:90%;">Gestão de clientes</h1>
      </div>
      <div class="col-sm-4 py-3">
        <div class="row">
          <div class="col-sm-12">
            <h1 class="d-inline-block">ache já</h1>
            <h5 class="d-inline-block float-sm-right mt-3">
              <i class="fa fa-user-circle m-1" style="color: #2abca1;" aria-hidden="true"></i>
              Usuario</h5>
            </div>
          </div>
        </div>
      </div>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-sm-3 col-xl-2">
      <div class="list-group" style="">
        <h4 class="list-group-item">Categorias</h4>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="" class="list-group-item"><?php echo e($cat->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="" class="list-group-item active"> Todos</a>
      </div>
    </div>
    <div class="col-sm-6">
      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-block myCard" style="width:100%">
          <img class="" style="width:100px; height:auto;" src="img/logo.png" alt="Card image cap">
          <p class="d-inline-block" style="vertical-align: top;">
            <?php echo e($client->name); ?> <br>
            <?php echo e($client->city->name); ?> <?php echo e($client->city->state_id); ?> <br>
            <?php echo e($client->street); ?> <?php echo e($client->street_number); ?> <?php if($client->phone): ?> <br>
            <?php echo e($client->phone); ?> <?php endif; ?> <br>
            <i><?php echo e($client->category->name); ?></i>
          </p>
          <p class="d-block" style="font-size:12px;font-weight: bold;;position:absolute;bottom:0rem;right:1.5rem;">
          Cliente desde: <?php echo e($client->created_at->setTimezone('-4')->format('d/m/Y')); ?></p>
          <div class="row" style="overflow:auto;">
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>