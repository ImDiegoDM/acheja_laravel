<div class="d-block myCard mb-sm-3" style="width:100%">
  <?php if($client->logo_url): ?>
    <img class="" style="width:100px; height:auto;" src="<?php echo e(env('APP_URL') . '/storage/app/' . $client->logo_url); ?>" alt="Card image cap">
  <?php else: ?>
    <p style="width:100px; height:auto; background-color:#e0e0e0;border-radius:9px; border: dotted #a2a2a2 3px; font-size:12px;" class="d-inline-block text-center p-3">Logo não encontrada, cadastre uma logo</p>
  <?php endif; ?>
  <p class="d-inline-block ml-1" style="vertical-align: top;">
    <?php echo e($client->name); ?> <br>
    <?php echo e($client->city->name); ?> <?php echo e($client->city->state_id); ?> <br>
    <?php echo e($client->street); ?> <?php echo e($client->street_number); ?> <?php if($client->phone): ?> <br>
    <?php echo e(Helper::mask($client->phone,'(**) ****-****')); ?> <?php endif; ?> <br>
    <i><?php echo e($client->category->name); ?></i>
  </p>
  <p class="d-block" style="font-size:12px;font-weight: bold;position:absolute;right:1.5rem;">
  Cliente desde: <?php echo e($client->created_at->setTimezone('-4')->format('d/m/Y')); ?></p>
</div>
