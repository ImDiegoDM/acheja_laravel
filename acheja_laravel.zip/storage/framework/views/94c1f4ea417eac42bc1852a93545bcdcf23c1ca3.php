<div class="row py-3 clientBackground <?php echo e($client->actived ? " active" : " disable"); ?>" style=>
  <div class="col-sm-6">
    <h1 class="mb-0"><?php echo e($client->name); ?></h1>
    <h4 class="ml-4"><?php echo e($client->category->name); ?></h4>
    <div class="d-inline-block" style="font-size:12px;position: absolute; bottom:-29px;">
      <?php if($client->actived): ?>
        <p>Criado em <?php echo e($client->created_at->setTimezone('-4')->format('d/m/Y')); ?> <br>
          <?php if($client->last_activated_at): ?>
            Ativado pela ultima vez em <?php echo e($client->last_activated_at->setTimezone('-4')->format('d/m/Y')); ?></p>
          <?php endif; ?>
      <?php else: ?>
        <p>Cliente atualmente desativado</p>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-sm-6 pr-5">
    <?php if($client->logo_url): ?>
      <img class="d-inline-block float-sm-right" style="max-width:206px; max-height:116px;" src="<?php echo e(env('APP_URL') . '/storage/app/' . $client->logo_url); ?>" alt="Card image cap">
    <?php else: ?>
      <p style="width:100px; height:auto; background-color:#e0e0e0;border-radius:9px; border: dotted #a2a2a2 3px; font-size:12px;" class="d-inline-block text-center p-3">Logo não encontrada, cadastre uma logo</p>
    <?php endif; ?>
  </div>
</div>
