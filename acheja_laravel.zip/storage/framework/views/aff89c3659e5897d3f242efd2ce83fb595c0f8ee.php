<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-2 pt-2 px-0">
        <a href="<?php echo e(env('APP_URL').'/admin/home'); ?>"><img src="<?php echo e(URL::asset('public/img/acheja.png')); ?>" class="p-relative horizontal-center " style="width:100%;" alt=""></a>
      </div>
      <div class="col-sm-7 pt-2 ">
        <h3 class="p-relative horizontal-center float-sm-right text-center menu-name smooth-border" style="width:90%;">Gestão de clientes</h3>
      </div>
      <div class="col-sm-3">
        <?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
  </div>
  <hr class="mt-2 mb-4">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-sm-3 col-xl-2 ml-sm-5">
      <div class="list-group" style="">
        <h4 class="list-group-item">Categorias</h4>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a onclick=<?php echo e("goToCategory(".$cat->id.")"); ?> class="<?php
            if(intval(request()->category)==$cat->id){
              //dd(intval(request()->category));
              echo "list-group-item active";
            }
            else {
              echo "list-group-item";
            }
           ?>" ><?php echo e($cat->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a onclick="cleanCategory()" class="<?php
        if(intval(request()->category)){
          //dd(intval(request()->category));
          echo "list-group-item";
        }
        else {
          echo "list-group-item active";
        }
         ?>"> Todos</a>
      </div>
      <div class="list-group mt-4" style="">
        <h4 class="list-group-item">Cidades</h4>
        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a onclick="<?php echo e("goToCity(".$city->id.")"); ?>" class="<?php
            if(intval(request()->city)==$city->id){
              //dd(intval(request()->category));
              echo "list-group-item active";
            }
            else {
              echo "list-group-item";
            }
           ?>"><?php echo e($city->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a onclick="cleanCity()" class="<?php
        if(intval(request()->city)){
          //dd(intval(request()->category));
          echo "list-group-item";
        }
        else {
          echo "list-group-item active";
        }
         ?>"> Todos</a>
      </div>
    </div>
    <div class="col-sm-6 ml-sm-5">
      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e('./client/'.$client->id); ?>" class="d-block myCard mb-sm-3" style="width:100%">
          <?php if($client->logo_url): ?>
            <img class="" style="width:100px; height:auto;" src="<?php echo e(env('APP_URL') . '/storage/app/' . $client->logo_url); ?>" alt="Card image cap">
          <?php else: ?>
            <p style="width:100px; height:auto; background-color:#e0e0e0;border-radius:9px; border: dotted #a2a2a2 3px; font-size:12px;" class="d-inline-block text-center p-3">Logo não encontrada, cadastre uma logo</p>
          <?php endif; ?>
          <p class="d-inline-block ml-1" style="vertical-align: top;">
            <?php echo e($client->name); ?> <br>
            <?php echo e($client->city->name); ?> <?php echo e($client->city->state_id); ?> <br>
            <?php echo e($client->street); ?> <?php echo e($client->street_number); ?> <?php if($client->phone): ?> <br>
            <?php echo e(Helper::mask($client->phone,'(**) ****-****')); ?> <?php endif; ?> <br>
            <i><?php echo e($client->category->name); ?></i>
          </p>
          <p class="d-block" style="font-size:12px;font-weight: bold;position:absolute;right:1.5rem;">
          Cliente desde: <?php echo e($client->created_at->setTimezone('-4')->format('d/m/Y')); ?></p>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <script src="<?php echo e(URL::asset('public/js/Filter.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>