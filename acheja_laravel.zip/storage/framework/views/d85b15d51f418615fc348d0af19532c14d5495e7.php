<?php $__env->startSection('top'); ?>
  <div class="container-fluid">
    <div class="row m-0">
      <div class="col-sm-2 pt-2 px-0">
        <a href="<?php echo e(env('APP_URL').'/admin/home'); ?>"><img src="<?php echo e(URL::asset('public/img/acheja.png')); ?>" class="p-relative horizontal-center " style="width:100%;" alt=""></a>
      </div>
      <div class="col-sm-7 pt-2 ">
        <h4 class="p-relative horizontal-center float-sm-right text-center menu-name smooth-border" style="width:90%;">Usuario</h4>
      </div>
      <div class="col-sm-3">
        <?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  <hr class="mt-2 mb-2">
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="myContainer px-2">
    <?php if(\Session::has('success')): ?>
      <script type="text/javascript">
      $(document).ready(function (){
        $('#message .alert .exit').on('click', function () {
          $('#message').slideUp( 1000 );
        });
      });
      </script>
      <div class="col-sm-12 navbar-collapse collapse show" id="message">
        <div class="alert alert-success" role="alert">
          <strong>Sucesso!</strong> <?php echo \Session::get('success'); ?>

          <strong class="exit">x</strong>
        </div>
      </div>
    <?php endif; ?>
    <h3 class=" mb-3">Informações pessoais</h3>
    <div class="leftBorder col-sm-6 px-2">
      <h4><?php echo e($user->name); ?></h4>
      <p class="ml-4 mb-1">E-mail: <span class="userInfo"><?php echo e($user->email); ?></span></p>
      <p class="ml-4 mb-1">Telefone: <span class="userInfo"><?php echo e(Helper::mask($user->phone,'(**) ****-****')); ?></span></p>
      <p class="ml-4 mb-1">Tipo: <span class="userInfo"><?php echo e($user->user_type->name); ?></span></p>
      <p class="ml-4 mb-1">Possuiu acesso: <span class="userInfo"><?php if($user->have_acess): ?><span>sim</span> <?php else: ?> <span >não</span><?php endif; ?></span></p>
      <p class="ml-4 mb-1">Email confirmado: <span class="userInfo"><?php if($user->confirm_email): ?><span>sim</span> <?php else: ?> <span>não</span><?php endif; ?></span></p>
      <p class="ml-4 mb-1">Criado em: <span class="userInfo"><?php echo e($user->created_at->setTimezone('-4')->format('d/m/Y')); ?></span></p>
    </div>
    <div class="col-sm-6">
      <form class="" action="<?php echo e(env('APP_URL').'/admin/user/'.$user->id.'/giveAcess'); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <button type="submit" name="button">Dar acesso</button>
      </form>
      <button type="button" name="button">Remover acesso</button>
      <button type="button" name="button">Redefinir Senha</button>
    </div>
    <h3 class="my-3"> Clientes que este usuario possui</h3>
    <div class="leftBorder px-4">
      <?php $__currentLoopData = $user->clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-9">
            <a href="<?php echo e(env('APP_URL')); ?>/admin/client/<?php echo e($client->id); ?>">
            <?php echo $__env->make('layout.client-line', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </a>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>