<?php $__env->startComponent('mail::message'); ?>
Olá, você acaba de ganhar acesso a plataforma do Ache Já lá você pode cenferir como anda as visualizações por lá e ainda cadastrar promoçoes e tickets.

Para poder acessar a plataforma você precisa cadastrar uma senha, basta clicar no botão e baixo e cadastrar a sua senha.

<?php $__env->startComponent('mail::button', ['url' =>env('APP_URL').'/public/users/setpassword?token='.$token]); ?>
Cadastrar Senha
<?php echo $__env->renderComponent(); ?>

equipe,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
